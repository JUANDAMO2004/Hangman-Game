const words: string[] = [
        'APPLE',
        'CHAIR',
        'ELEPHANT',
        'MOON',
        'HAPPINESS',
        'MOUNTAIN',
        'BICYCLE',
        'SUNSHINE',
        'BOOK',
        'OCEAN',
        'COMPUTER',
        'GUITAR',
        'BUTTERFLY',
        'ADVENTURE',
        'RAINFOREST',
        'CHOCOLATE',
        'UNIVERSE',
        'FRIENDSHIP',
        'SERENITY',
        'STARFISH'
    ];


export function getRandomWord(){
    const randomIndex = Math.floor(Math.random() * words.length);
    return words[randomIndex];
    
}
